import { ApiError } from '@/lib/api/api-error';

type LogLevel = 'info' | 'warn' | 'error' | 'debug';

const COLORS = {
  reset: '\x1b[0m',
  gray: '\x1b[90m',
  blue: '\x1b[34m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  cyan: '\x1b[36m',
  white: '\x1b[97m',
  green: '\x1b[32m',
  magenta: '\x1b[35m',
  bold: '\x1b[1m',
};

const SENSITIVE_KEYS = new Set([
  'authorization',
  'cookie',
  'set-cookie',
  'password',
  'currentpassword',
  'newpassword',
  'token',
  'accesstoken',
  'refreshtoken',
  'secret',
  'clientsecret',
  'apikey',
  'email',
  'address',
  'phonenumber',
  'phone',
  'dateofbirth',
]);

class Logger {
  private readonly isDevelopment =
    process.env.NODE_ENV === 'development';

  /**
   * Remove sensitive information before logging.
   */
  private sanitize(data: unknown, depth = 0): unknown {
    if (depth > 10) {
      return '[Maximum depth exceeded]';
    }

    if (data === null || data === undefined) {
      return data;
    }

    if (Array.isArray(data)) {
      return data.map((item) => this.sanitize(item, depth + 1));
    }

    if (typeof data !== 'object') {
      return data;
    }

    if (data instanceof Error) {
      return this.serializeError(data);
    }

    const sanitized: Record<string, unknown> = {};

    for (const [key, value] of Object.entries(data)) {
      const normalizedKey = key.toLowerCase().replace(/[-_]/g, '');

      if (SENSITIVE_KEYS.has(normalizedKey)) {
        sanitized[key] = '[REDACTED]';
        continue;
      }

      sanitized[key] = this.sanitize(value, depth + 1);
    }

    return sanitized;
  }

  /**
   * Serialize native errors without losing their stack traces.
   */
  private serializeError(error: Error): Record<string, unknown> {
    return {
      name: error.name,
      message: error.message,
      stack: error.stack,
      ...(error instanceof ApiError && {
        timestamp: error.timestamp,
        status: error.status,
        error: error.error,
        path: error.path,
        validationErrors: this.sanitize(error.validationErrors),
      }),
      ...(error.cause !== undefined && {
        cause: error.cause instanceof Error
          ? this.serializeError(error.cause)
          : this.sanitize(error.cause),
      }),
    };
  }

  /**
   * Convert any error or unknown value into loggable data.
   */
  private serializeData(data: unknown): unknown {
    if (data instanceof Error) {
      return this.serializeError(data);
    }

    return this.sanitize(data);
  }

  /**
   * Format JSON with colors for development.
   */
  private formatJson(data: unknown): string {
    let json: string;

    try {
      json = JSON.stringify(this.serializeData(data), null, 2);
    } catch {
      return `${COLORS.red}[Unable to serialize data]${COLORS.reset}`;
    }

    if (!json) {
      return `${COLORS.gray}undefined${COLORS.reset}`;
    }

    return json
      .split('\n')
      .map((line) => {
        // Property names
        line = line.replace(
          /^(\s*)"([^"]+)"(\s*:)/,
          `$1${COLORS.cyan}"$2"${COLORS.reset}$3`
        );

        // String values
        line = line.replace(
          /(:\s*)"((?:\\.|[^"\\])*)"/g,
          `$1${COLORS.green}"$2"${COLORS.reset}`
        );

        // Numbers
        line = line.replace(
          /(:\s*)(-?\d+\.?\d*)/g,
          `$1${COLORS.yellow}$2${COLORS.reset}`
        );

        // Booleans and null
        line = line.replace(
          /(:\s*)(true|false|null)\b/g,
          `$1${COLORS.magenta}$2${COLORS.reset}`
        );

        return line;
      })
      .join('\n');
  }

  /**
   * Format a log message.
   */
  private formatMessage(
    level: LogLevel,
    context: string,
    message: string,
    data?: unknown
  ): string {
    const timestamp = new Date().toISOString();

    const sanitizedData = data !== undefined
      ? this.serializeData(data)
      : undefined;

    // Production: structured JSON, no ANSI colors.
    if (!this.isDevelopment) {
      return JSON.stringify({
        timestamp,
        level: level.toUpperCase(),
        context,
        message,
        ...(sanitizedData !== undefined && {
          data: sanitizedData,
        }),
      });
    }

    const color = {
      info: COLORS.blue,
      warn: COLORS.yellow,
      error: COLORS.red,
      debug: COLORS.gray,
    }[level];

    const prefix =
      `${COLORS.gray}[${timestamp}]${COLORS.reset} ` +
      `${color}${COLORS.bold}[${level.toUpperCase()}]${COLORS.reset} ` +
      `${COLORS.cyan}[${context}]${COLORS.reset}`;

    let output =
      `${prefix} ${COLORS.white}${message}${COLORS.reset}`;

    return output;
  }

  /**
   * Write to the appropriate console output.
   */
  private write(level: LogLevel, message: string): void {
    switch (level) {
      case 'error':
        console.error(message);
        break;

      case 'warn':
        console.warn(message);
        break;

      case 'debug':
        console.debug(message);
        break;

      default:
        console.info(message);
    }
  }

  info(context: string, message: string, data?: unknown): void {
    this.write(
      'info',
      this.formatMessage('info', context, message, data)
    );
  }

  warn(context: string, message: string, data?: unknown): void {
    this.write(
      'warn',
      this.formatMessage('warn', context, message, data)
    );
  }

  /**
   * Log native errors, ApiErrors, or arbitrary error details.
   */
  error(context: string, error: unknown, data?: unknown): void {
    const isError = error instanceof Error || error instanceof ApiError;

    const message = error.message ?? 'An unexpected error occurred.';

    const details = {
      ...(isError && this.serializeError(error)),
      ...(data !== undefined && {
        details: this.serializeData(data),
      }),
      ...(!isError && {
        error: this.serializeData(error),
      }),
    };

    const httpPrefix = error instanceof ApiError
      ? `HTTP ${error.status} | ${error.error} | `
      : '';

    this.write(
      'error',
      this.formatMessage(
        'error',
        context,
        `${httpPrefix}${message}`,
        details
      )
    );
  }

  debug(context: string, message: string, data?: unknown): void {
    if (this.isDevelopment) {
      this.write(
        'debug',
        this.formatMessage('debug', context, message, data)
      );
    }
  }

  /**
   * Remove query parameter values from URLs.
   */
  private sanitizeUrl(url: string): string {
    try {
      const parsed = new URL(url, 'http://localhost');

      parsed.search = '';
      parsed.hash = '';

      return parsed.origin === 'http://localhost'
        ? `${parsed.pathname}`
        : parsed.toString();
    } catch {
      return url.split('?')[0].split('#')[0];
    }
  }

  /**
   * Outgoing HTTP request.
   */
  apiRequest(
    method: string,
    url: string,
    payload?: unknown,
    headers?: Record<string, string>
  ): void {
    const details = this.isDevelopment
      ? {
          ...(headers && {
            headers: this.sanitize(headers),
          }),
          ...(payload !== undefined && {
            payload: this.sanitize(payload),
          }),
        }
      : undefined;

    this.info(
      'HTTP_OUTGOING',
      `${method} ${this.sanitizeUrl(url)}`);
  }

  /**
   * Outgoing HTTP successful response.
   */
  apiResponse(
      method: string,
      url: string,
      status: number,
      payloadLength: number,
      headers?: Record<string, string>,
      durationMs?: number
  ): void {
    const details = [
      `HTTP ${status}`,
      `payloadLength: ${payloadLength}`,
      durationMs !== undefined && `duration: ${durationMs}ms`,
      this.isDevelopment && headers &&
      `headers: ${JSON.stringify(this.sanitize(headers))}`,
    ].filter(Boolean);

    this.info(
        'HTTP_INCOMING',
        `${method} ${this.sanitizeUrl(url)} | ${details.join(' | ')}`
    );
  }

  apiFailure(
      method: string,
      url: string,
      status: number,
      statusText: string,
      headers?: Record<string, string>,
      body?: unknown,
      durationMs?: number
  ): void {
    const details = [
      `HTTP ${status} ${statusText}`,
      durationMs !== undefined && `duration: ${durationMs}ms`,
      this.isDevelopment && headers &&
      `headers: ${JSON.stringify(this.sanitize(headers))}`,
      this.isDevelopment && body !== undefined &&
      `payload: ${JSON.stringify(this.sanitize(body))}`,
    ].filter(Boolean);

    this.error(
        'HTTP_OUTGOING',
        `${method} ${this.sanitizeUrl(url)} | ${details.join(' | ')}`
    );
  }

  /**
   * Incoming HTTP request.
   */
  httpRequest(
    method: string,
    url: string,
    headers?: Record<string, string>
  ): void {
    this.info(
      'HTTP_INCOMING',
      `${method} ${this.sanitizeUrl(url)}`,
      this.isDevelopment && headers
        ? { headers: this.sanitize(headers) }
        : undefined
    );
  }

  /**
   * Incoming HTTP response.
   */
  httpResponse(
    method: string,
    url: string,
    status: number,
    durationMs: number
  ): void {
    const level: LogLevel =
      status >= 500 ? 'error'
        : status >= 400 ? 'warn'
          : 'info';

    this.write(
      level,
      this.formatMessage(
        level,
        'HTTP_INCOMING',
        `${method} ${this.sanitizeUrl(url)} | HTTP ${status}`,
        {
          status,
          durationMs,
        }
      )
    );
  }

  /**
   * Log standardized API errors.
   */
  apiError(error: ApiError): void {
    this.error('API', error);
  }
}

export const logger = new Logger();

export default logger;