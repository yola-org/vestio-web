import type { ApiCallOptions, ApiErrorConfig } from '@/lib/api/result';
import type { FieldValidationError } from '@/types/api';
import {ApiError} from "@/lib/api/api-error.ts";

export const FALLBACK_ERROR_MESSAGE = 'An unexpected error occurred.';

/**
 * Extracts normalized error details from any thrown/returned error value.
 */
export function getApiError(error: unknown, options?: ApiCallOptions): ApiError {
  if (error instanceof ApiError) {
    if (options){
      const handlerMessage = error.code === undefined ? FALLBACK_ERROR_MESSAGE : options.errors?.[error.code];
      return {...error, message: handlerMessage} as ApiError;
    }
    return error;
  }

  return ApiError.createApiError({
    timestamp: new Date().toISOString(),
    status: 500,
    error: 'ERR_UNEXPECTED',
    message: error.message ?? FALLBACK_ERROR_MESSAGE,
    path: null,
    validationErrors: [],
  });
}
