import type { ErrorResponse } from '@/types/api';

export class ApiError extends Error implements ErrorResponse {
  timestamp: string;
  status: number;
  error: string;
  path: string;
  validationErrors: ErrorResponse['validationErrors'];
  stack: unknown;

  constructor(data: ErrorResponse) {
    super(data.message || data.error || 'An error occurred.');
    this.name = 'ApiError';

    this.timestamp = data.timestamp;
    this.status = data.status;
    this.error = data.error;
    this.path = data.path;
    this.validationErrors = data.validationErrors ?? [];

    Object.setPrototypeOf(this, new.target.prototype);
  }

  static createApiError(
      data: unknown,
      status: number,
      statusText: string,
      path: string,
      fallbackMessage: string
  ): ApiError {
    // Backend returned a valid ErrorResponse
    if (this.isErrorResponse(data)) {
      return new ApiError({
        ...data
      });
    }

    // Backend returned an unexpected response (runtime exception,
    // proxy error, HTML response, empty response, etc.)
    return new ApiError({
      timestamp: new Date().toISOString(),
      status,
      error: statusText || 'HTTP_ERROR',
      message: fallbackMessage,
      path,
      validationErrors: [],
    });
  }

  static isErrorResponse(data: unknown): data is ErrorResponse {
    return (
        typeof data === 'object' &&
        data !== null &&
        'timestamp' in data &&
        'status' in data &&
        'error' in data &&
        'message' in data &&
        'path' in data &&
        'validationErrors' in data
    );
  }

  toJSON(): ErrorResponse & {
    name: string;
    stack?: string;
  } {
    return {
      name: this.name,
      message: this.message,
      timestamp: this.timestamp,
      status: this.status,
      error: this.error,
      path: this.path,
      validationErrors: this.validationErrors,
      stack: this.stack,
    };
  }

}
