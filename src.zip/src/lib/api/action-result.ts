
import 'server-only';

import { getTranslations } from 'next-intl/server';
import { ApiError } from '@/lib/api/api-error';
import { getApiError } from '@/lib/api/errors';
import type { ApiCallOptions, ApiResult } from '@/lib/api/result';

export type { ApiCallOptions, ApiError, ApiResult } from '@/lib/api/result';

/**
 * Wrapper for server actions that catches errors and returns the same
 * {@link ApiResult} shape used by the client layer.
 *
 * Error resolution (options, error codes, fallback message) is shared with
 * `callApi`, so a server action and a client call are handled identically.
 *
 * @example
 * ```ts
 * 'use server';
 * import { runAction } from '@/lib/api/action-result';
 *
 * export async function getUserAction(id: string) {
 *   return runAction(async () => request<User>(`/users/${id}`));
 * }
 * ```
 */
export async function runAction<T>(
  action: () => Promise<T>,
  options: ApiCallOptions = {}
): Promise<ApiResult<T>> {
  try {
    return { success: true, data: await action() };
  } catch (error) {
    console.log(error);
    const t = await getTranslations();
    const fallbackMessage = t('errors.apiFallback');
    if (error instanceof ApiError) {
      return {success: false, error : error.toJSON()};
    }
    console.error(error);
    let resolvedError : ApiError = getApiError(error, options);
    return {
      success: false,
      error: resolvedError
    };
  }
}
